# BioLockJ_Lib.R contains the library of functions shared by multiple BioLockJ R script modules. 


addPlotLabel <- function( label, size, color, las, side, rowIndex, colIndex ) {
   mtext( bquote(bold(.( label ))), outer=TRUE, cex=size, side=side, las=las, line=colIndex, adj=rowIndex, col=color )
}


displayPval <- function( pval ) {
   return( paste( sprintf(getProperty("r.pValFormat", "%1.2g"), pval) ) )
}


getCexAxis <- function( labels ) {
   nchars = sum(nchar(labels)) + length(labels) - 1
   if( nchars < getProperty("r.plotWidth")) {
      return( 1 )
   }
   else if( nchars < (getProperty("r.plotWidth")+7) ) {
      return( 0.9 )
   }
   else if( nchars < (getProperty("r.plotWidth")+15) ) {
      return( 0.8 )
   }
   else if( nchars < (getProperty("r.plotWidth")+24) ) {
      return( 0.7 )
   }
   return( cexAxisMin )
}


getColIndexes <- function( otuTable, attNames ) {
   cols = vector( mode="integer" )
   if( !is.na(attNames) && length(attNames) > 0 ) {
      for( i in 1:length(attNames) ) {
         cols[i] = grep(TRUE, colnames(otuTable)==attNames[i])
      }
   }
   return( cols )
}


#return r.colorHighlight if any of the input values meet the r.pvalCutoff, otherwise return r.colorBase
getColor <- function( v ) {
   for( i in 1:length(v) ) {
      if( grepl("e", v[i]) || !is.na(v[i]) && !is.nan(v[i]) && ( v[i] <= getProperty("r.pvalCutoff", 0.05) ) ) {
         return( getProperty("r.colorHighlight", "black") )
      } 
   }
   return( getProperty("r.colorBase", "black") )
}


getColors <- function( n ) {
   return( get_palette( getProperty("r.colorPalette", "npg"), n ) )
}


getFactorGroups <- function( otuTable, metaCol, otuCol ) {
   vals = list()
   options = levels( metaCol )
   for( i in 1:length(options) ) {
      vals[[i]] = otuTable[metaCol==options[i], otuCol]
   }
   return( vals )
}


getLabels <- function( labels ) {
   if( getCexAxis(labels) == cexAxisMin ) {
      nchars = sum(nchar(labels)) + length(labels) - 1
      maxSize = ((getProperty("r.plotWidth")*2)+2)/length(labels)
      return( strtrim(labels, floor(maxSize) ) )
   }
   return( labels )
}


getLas <- function( labels ) {
   HORIZONTAL = 1
   VERTICAL = 3
   nchars = sum(nchar(labels)) + length(labels) - 1
   aveSize = sum(nchar(labels))/length(labels)
   las = HORIZONTAL
   if( (length(labels) > 5) && aveSize > 3 ) las = VERTICAL
   return( las )
}


getMaxAttLen <- function( v ) {
   max = 0
   for( i in 1:length(v) ) {
      if( nchar(v[i]) > max ) max = nchar(v[i])
   }
   return( max )
}


getModuleDir <- function() {
	if( pipelineDir == getModuleScriptDir() ){
		return( pipelineDir )
	}
	return( dirname( getModuleScriptDir() ) )
}


getPath <- function( rootDir, name ) {
   return( file.path( rootDir, paste0( getProperty("internal.pipelineName"), "_", name ) ) )
}


getPlotTitle <- function( line1, line2 ) {
   if( (nchar(line1) + nchar(line2) ) > getProperty("r.plotWidth") ) {
      return( paste0( line1, "\n", line2 ) )
   }
   return( paste( line1, line2 ) )
}

getMasterProperties <- function() {
   testDir = getModuleScriptDir()
   propFile = vector( mode="character" )
   while( length( propFile ) == 0 && testDir != "/" ) {
      propFile = list.files( testDir, "MASTER.*.properties", full.names=TRUE )
      testDir = dirname( testDir )
   }
   if( length( propFile ) == 0 ) {
      stop( "MASTER property file not found!" )
   }
   return( propFile )
}

getProperty <- function( name, val=NULL ) {
   return ( suppressWarnings( parseConfig( name, val ) ) )
}

parseConfig <- function( name, val=NULL ) {
   config = read.properties( configFile )
   prop = config[[ name ]]

   if( is.null( prop ) ) {
      return( val )
   }
   if( is.null( prop ) ) {
      return( NULL )
   } 
   if( str_trim( prop ) == "Y" ) {
      return( TRUE )
   }
   if( str_trim( prop ) == "N" ) {
      return( FALSE )
   }
   if( !is.na( as.numeric( prop ) ) && grepl( ",", prop ) ) {
      return( as.numeric( unlist( strsplit( prop, "," ) ) ) )
   }
   if( is.character( prop ) && grepl( ",", prop ) ) {
      return( str_trim( unlist( strsplit( prop, "," ) ) ) )
   }
   if( !is.na( as.numeric( prop ) ) ) {
      return( as.numeric( prop ) )
   }

   return( str_trim( prop ) )
}
   

getValuesByName <- function( vals, name ) {
   return( as.vector( vals[names(vals)==name] ) )
}


pValueTestName <- function( attName, isParametric ) {
   if( attName %in% binaryFields && isParametric ) return ( "T-Test" )
   if( attName %in% binaryFields && !isParametric ) return ( "Wilcox" )
   if( attName %in% nominalFields && isParametric ) return ( "ANOVA" )
   if( attName %in% nominalFields && !isParametric ) return ( "Kruskal" )
   if( attName %in% numericFields && isParametric ) return ( "Pearson" )
   if( attName %in% numericFields && !isParametric ) return ( "Kendall" )
}

reportStatus <- function() {
   conn = file( paste0( mainScript, "_Failures" ), open="r" )
   errors = readLines( conn )
   close( conn )
   foundError = FALSE
   if( length( errors ) > 0 ) {
      for ( i in 1:length( errors ) ) {
         if( grepl( "Error", errors[i] ) ) {
            foundError = TRUE
         }
      }
   }
   if( !foundError ) {
      file.create( paste0( mainScript, "_Success" ) )
      if( file.exists( paste0( mainScript, "_Failures" ) ) ) {
         file.remove( paste0( mainScript, "_Failures" ) )
      }
   }
}


runProgram <- function() {
   errorLog = file( paste0( mainScript, "_Failures" ), open="wt" )
   sink( errorLog, type="message" )
   if( r.debug ) print( paste( "Pipeline dir: ", pipelineDir ) )
   try( main() )
   sink( type="message" )
   close( errorLog )
}

stopifnot( library( properties, logical.return=TRUE ) && library( stringr, logical.return=TRUE ))
configFile = getMasterProperties()
pipelineDir = dirname( configFile )
r.debug = getProperty("r.debug", FALSE)
binaryFields = getProperty("internal.binaryFields", vector( mode="character" ) )
nominalFields = getProperty("internal.nominalFields", vector( mode="character" ) )
numericFields = getProperty("internal.numericFields", vector( mode="character" ) )
allAtts = c( binaryFields, nominalFields, numericFields )
cexAxisMin = 0.65
